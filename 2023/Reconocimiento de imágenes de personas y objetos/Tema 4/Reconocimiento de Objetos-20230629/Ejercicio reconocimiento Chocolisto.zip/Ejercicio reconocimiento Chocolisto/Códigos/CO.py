import cv2
import numpy as np
import imutils
import os

#Creamos la carpeta para recolectar datos 
Datos = 'Chocolisto/N'
if not os.path.exists(Datos):
    print('Carpeta creada: ',Datos)
    os.makedirs(Datos) 

cap = cv2.VideoCapture(0,cv2.CAP_DSHOW) #recolectar los datos

#para recortar un rectangulo para tener solo lo que deseo
x1, y1 = 190, 80
x2, y2 = 450, 398

count = 0 #para con este valor guardar cada una de las imagenes y del fondo
while True:

    ret, frame = cap.read()
    if ret == False: break
    imAux = frame.copy() #para caturar la imagen sin el rectangulo azul
    cv2.rectangle(frame,(x1,y1),(x2,y2),(255,0,0),2) #dibujar rectangulo para capturar objeto 

    objeto = imAux[y1:y2,x1:x2] #le asigno la imagen que tome
    objeto = imutils.resize(objeto,width=38) #redmensinar la imagen
    #print(objeto.shape)

    k = cv2.waitKey(1)
    if k == ord('s'): #con s guarda en la carpeta que tiene la variable datos que en este caso son las positivas 
        cv2.imwrite(Datos+'/objeto_{}.jpg'.format(count),objeto) #dice como guardo la imagen
        print('Imagen guardada:'+'/objeto_{}.jpg'.format(count))#que ya la guardo
        count = count +1#aumenta la variable count para seguir guardando imagen 
    if k == 27:
        break

    cv2.imshow('frame',frame)
    cv2.imshow('objeto',objeto) #visualizo la imagen del rectangulo

cap.release()
cv2.destroyAllWindows()