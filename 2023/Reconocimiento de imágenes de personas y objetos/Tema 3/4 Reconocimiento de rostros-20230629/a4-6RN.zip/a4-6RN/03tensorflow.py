from IPython.core import history
import tensorflow as tf
import numpy as np 

entrada = np.array([[0,0,0],[0,0,1],[0,1,0],[0,1,1],[1,0,0]])
respuesta = np.array([[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]])

oculta1 = tf.keras.layers.Dense(units=4, input_shape=[3,])
salida = tf.keras.layers.Dense(units=5, input_shape=[4,])
modelo = tf.keras.Sequential([oculta1, salida])

modelo.compile(
    optimizer=tf.keras.optimizers.Adam(0.1),
    loss="mean_squared_error"
)

historia1 = modelo.fit(entrada, respuesta, epochs=1000, verbose=False)

import matplotlib.pyplot as plt

plt.xlabel("epocas")
plt.ylabel("valor del error")
plt.plot(historia1.history["loss"])

resultado = modelo.predict([[0,1,1]])
print("*3 RESULTADO",resultado)

resultado = modelo.predict([[1,0,1]])
print("*5 RESULTADO",resultado)

resultado = modelo.predict([[0,1,0]])
print("*2 RESULTADO",resultado)



