import numpy as np
# FUNCIÓN DE ACTIVACIÓN
def activacion(x, derivada=False):
  if derivada == True:
    s = 1 / (1 + np.exp(-x))
    return s * (1 - s)
  return 1 / (1 + np.exp(-x))

# 5 ENTRADAS CON 3 datos CADA UNA (TRAINING DATA) 
x = np.array([[0,0,0],[0,0,1],[0,1,0],[0,1,1],[1,0,0]])

# 5 SALIDAS ESPERADAS
y = np.array([[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]])

tasaAprendizaje = 0.1

np.random.seed(1)
# INICIALIZACIÓN DE LOS PESOS CON VALORES ALEATORIOS, USAR INTERVALO [-1,+1]
# w0 DE LA CAPA DE ENTRADA A LA CAPA OCULTA
w0 = 2 * np.random.random((3,4)) - 1
print(w0)

# w1 DE LA CAPA OCULTA A LA CAPA DE SALIDA
w1 = 2 * np.random.random((4,5)) - 1
print(w1)

# ENTRENAMIENTO DE LA RED: ALGORITMO BACKPROPAGATION
epocas =  4000
f
or epoca in range(epocas):  # FEED-FORWARD PARA CALCULAR LAS SALIDAS CON LOS PESOS ACTUALES
  capa0 = x
  capa1 = activacion(np.dot(capa0, w0))
  capa2 = activacion(np.dot(capa1, w1))

  # CALCULO DEL ERROR EN ESTA EPOCA
  errorY = y - capa2

  # SE QUIERE MINIMIZAR EL errorY
  if epoca % (epocas / 10) == 0: # DESPLIEGA CADA 100 EPOCAS
    print("Error: "+ str(np.mean(np.abs(errorY)))) 

  # BACKPROPAGATION DEL ERROR USANDO LA REGLA DE LA CADENA
  capa2Delta = errorY * activacion(capa2, derivada=True)
  errorCapa1 = capa2Delta.dot(w1.T)
  capa1Delta = errorCapa1 * activacion(capa1, derivada=True)

  # SE USAN LAS DELTAS PARA ACTUALIZAR LOS PESOS QUE REDUCEN EL ERROR (DESCENSO DEL GRADIENTE)
  w1 += capa1.T.dot(capa2Delta) * tasaAprendizaje
  w0 += capa0.T.dot(capa1Delta) * tasaAprendizaje

# RESULTADO DEL APRENDIZAJE
print(w0)
print(w1)

# USAMOS LOS PESOS RESULTANTES DEL ENTRENAMIENTO PARA PROBAR (TEST DATA)
# COLOCAMOS DOS DESCONOCIDOS Y DOS CONOCIDOS (SEGUNDO Y CUARTO)
x = np.array([[0,0,0],[0,1,1],[1,0,0],[1,0,1]])

capa0 = x
capa1 = activacion(np.dot(capa0, w0))
yEstimada = activacion(np.dot(capa1, w1))

print("\nEntrada de prueba:")
print(x)
print("\nResultados con:")
print(yEstimada)
print("Esperaba ? 1 ? 0")



