import numpy as np
import matplotlib.pyplot as plt

#FUNCION A OPTIMIZAR
funcion = lambda x: x**2
datosX = np.linspace(-10,10,500)
plt.plot(datosX, funcion(datosX))
plt.show()

# DERIVADA DE LA FUNCIÓN
def derivada(x):
    return 2*x

# ALGORITMO DEL GRADIENTE
def gradiente(x, precision, tasaAprendizaje):
    # VARIABLES PARA VISUALIZAR LOS PUNTOS UTILIZADOS
    listaX, listaY = [x], [funcion(x)]
    # ITERACION PARA BUSCAR MINIMIZAR
    while True:
        dX = - derivada(x)
        # NUEVO VALOR DE X
        x += (tasaAprendizaje * dX)
        # AÑADIMOS VALORES A LA LISTA
        listaX.append(x)
        listaY.append(funcion(x))
        # SE TERMINA CUANDO SE ALCANZA LA CONDICIÓN
        if abs(listaX[-1] - listaX[-2]) <= precision:
            break

    # GRAFICACIÓN DE DATOS   
    print ("Mínimo: "+ str(x))
    print ("Iteraciones (Epocas): " + str(len(listaX)))
    print("Precisión: "+str(precision))
    print("Tasa de aprendizaje (Learning rate): "+str(tasaAprendizaje))
    
    plt.subplot(1,2,2)
    plt.scatter(listaX, listaY, c="g")
    plt.plot(listaX, listaY ,c="g")
    plt.plot(datosX, funcion(datosX), c="r")
    plt.title("Descenso del gradiente")
    plt.show()

gradiente(9, 0.001, 0.1)
# MODIFICAR tasaAprendizaje 0.1 0.2