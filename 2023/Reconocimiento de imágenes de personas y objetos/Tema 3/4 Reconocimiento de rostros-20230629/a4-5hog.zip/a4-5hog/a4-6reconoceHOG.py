import imutils
import cv2
from google.colab.patches import cv2_imshow
import matplotlib.pyplot as plt

archivos = ["per1.png","per2.png","per3.png","per4.png"]

# CONFIGURA EL DETECTOR DE PERSONAS USANDO HOG
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# DESPLIEGA LOS PARÁMETROS DE LA FUNCIÓN detectMultiScale
help(cv2.HOGDescriptor().detectMultiScale)

for archivo in archivos:
  imagenBGR = cv2.imread(archivo)
  imagenRGB = cv2.cvtColor(imagenBGR, cv2.COLOR_BGR2RGB)
  imagenTamEstandar = imutils.resize(imagenRGB, width=min(400, imagenRGB.shape[1]))
  original = imagenRGB.copy()
	
  # IDENTIFICA PERSONAS EN CADA IMAGEN
  (rects, weights) = hog.detectMultiScale(imagenRGB, winStride=(3, 3), padding=(9, 9), scale=1.1)

  # SE COLOCAN RECTÁNGULOS SOBRE LAS PERSONAS IDENTIFICADAS, INCLUYENDO Falsos positivos (PAREIDOLIA)
  for (x, y, w, h) in rects:
    cv2.rectangle(imagenRGB, (x, y), (x + w, y + h), (0, 255, 0), 1)

  # DESPLIEGA LAS IMÁGENES ORIGINAL Y CON LAS PERSONAS DETECTADAS
  figura = plt.figure(figsize=(15, 7))
  figura.add_subplot(1, 2, 1)
  plt.imshow(original)
  plt.axis('off')
  plt.title("Original")

  figura.add_subplot(1, 2, 2)
  plt.imshow(imagenRGB)
  plt.axis('off')
  plt.title("Aplicando HOG en "+archivo)