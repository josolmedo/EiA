from skimage import data, color, feature
import cv2
from google.colab.patches import cv2_imshow
import matplotlib.pyplot as plt

#imagenBGR = cv2.imread("gato.png")
imagenBGR = cv2.imread("per4.png")
#imagenBGR = cv2.imread("rosa.jpg")

contraste = 1  # Cambiar contraste 1=no
brillo = 0 # Cambiar brillo 0=no

# AJUSTA BRILLO Y CONTRASTE CON UNA FUNCIÓN DE OpenCV
imagenAjustada = cv2.convertScaleAbs(imagenBGR, alpha=contraste, beta=brillo)
imagenGrises = cv2.cvtColor(imagenAjustada, cv2.COLOR_BGR2GRAY)
#imagenGrises = cv2.imread("gato.png", cv2.IMREAD_GRAYSCALE)

#cv2_imshow(imagenGrises)
vectorHOG, imagenHOG = feature.hog(imagenGrises, visualize=True)
fig, ax = plt.subplots(1, 2, figsize=(12, 6), subplot_kw=dict(xticks=[], yticks=[]))
ax[0].imshow(imagenGrises, cmap='gray')
ax[0].set_title('Tonos de gris')

ax[1].imshow(imagenHOG, cmap='gray')
ax[1].set_title('Vectores de gradiente: HOG')
