# MeIA-segmentation
Repo for the MeIA - Vehicle Detection and Semantic Segmentation in Aerial Drone Images (HAGDAVS Dataset)

Losses: https://github.com/maxvfischer/keras-image-segmentation-loss-functions/tree/master